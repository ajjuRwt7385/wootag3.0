## Wootag.com | 3.0

Wootag Website 2019.

### Feathures:

All HTML files are compressed (see `_layouts/compress.html`).

Build for production:

`JEKYLL_ENV=production jekyll build`
